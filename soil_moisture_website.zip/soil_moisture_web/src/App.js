import Navigation from "./pages/navigation";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import { Link } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Predict from "./pages/Predict";
import Background from "./pages/Background";
import "./styles/App.css";
import Footer from "./pages/Footer";

const App = () => {
  return (
    <div className="container">
      <BrowserRouter>
        <Background />
        <Navigation />
        <Routes>
          <Route  path="/" element={<Home />}></Route>
          <Route  path="/About" element={<About />}></Route>
          <Route  path="/Predict" element={<Predict />}></Route>
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
};
export default App;
