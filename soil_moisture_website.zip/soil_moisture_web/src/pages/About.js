import React from 'react';
import Background from "../pages/Background"
import "../styles/about.css";

const About=()=>{
    const str="Welcome to our website dedicated to soil moisture prediction! We are passionate about providing accurate and reliable information on soil moisture levels to help farmers, land managers, and other stakeholders make informed decisions about crop planting, irrigation scheduling, and water management."
    return(
        <>
        <Background/>
        <div className="div_about">
            <h2>
                {str}
            </h2>
            
        </div>

        </>
    )
}
export default About;