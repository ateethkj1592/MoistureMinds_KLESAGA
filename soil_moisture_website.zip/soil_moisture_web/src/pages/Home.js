import React from "react";
import "../styles/Home.css";

const Home = () => {
  const str =
    "Predict the moisture in soil determines the field’s readiness for agricultural processing based on the parameters like texture, structure, organic matter content, salinity and depth.";
  return (
    <>
      <div>
        <div className="Home">
          <h1>Moisture Predictor</h1>
          <h2>{str}</h2>
        </div>
        <div className="wrapper">
               
        </div>
      </div>
    </>
  );
};
export default Home;
