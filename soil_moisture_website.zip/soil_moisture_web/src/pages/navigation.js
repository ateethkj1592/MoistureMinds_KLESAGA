import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import { NavLink } from "react-router-dom";
import "../styles/navbar.css";
function Navigation() {
  return (
    <div className="Container">
      <nav>
        <ul>
          <li>
            <NavLink to="/" className="navlink">
              Home
            </NavLink>
          </li>
          <li>
            <NavLink to="/About" className="navlink">
              About
            </NavLink>
          </li>
          <li>
            <NavLink to="/Predict" className="navlink">
              Predict
            </NavLink>
          </li>
        </ul>
      </nav>
    </div>
  );
}

export default Navigation;
