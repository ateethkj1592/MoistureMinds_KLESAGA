import React, { useEffect, useState } from "react";
import Background from "../pages/Background";
import "../styles/Predict.css";
import background from "../img/long.jpg";

const styles = {
  back: `url(${background})`,
};

const Predict = () => {
  const suggest = (e) => {
    const randomNumber = Math.floor(Math.random() * 5) + 1;
    return (
      <h2>
        Best crop suggested for this moisture level is: {low[randomNumber]}
      </h2>
    );
  };

  const [inputValue, setInputValue] = useState([]);

  const low = ["A", "B", "C", "Y", "Z", "D", "E", "F", "P", "Q"];

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };
  const str = "";
  const crop1 = "Sunflower";
  const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
  return (
    <>
      <Background />
      <div className="container">
        <label>
          Date from march 1 to 10:
          <select
            name="numbers"
            className="Input"
            value={inputValue}
            onChange={handleInputChange}
          >
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
          </select>
        </label>
        <div className="show">
          <div
            className={
              numbers[inputValue] < 5 ? "background-red" : "background-blue"
            }
          />
          <div className="div1">
            <h1>
              The Predicted soil moisture level on March {inputValue} is :{" "}
              {numbers[inputValue]}
            </h1>
          </div>
        </div>
        <h2>{suggest(numbers[inputValue])}</h2>
      </div>
    </>
  );
};

export default Predict;
