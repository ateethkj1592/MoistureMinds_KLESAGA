import React from "react";
import background from "../img/img.jpg";
const styles = {
  backgroundImage: `url(${background})`,
  backgroundSize: "cover",
  backgroundPosition: "center",
  backgroundRepeat: "no-repeat",
};

const MyComponent = () => {
  return (
    <>
      <div style={styles}></div>
    </>
  );
};
export default MyComponent;
